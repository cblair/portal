<?php

$lang['cal_su']			= "Su";
$lang['cal_mo'] 		= "Ma";
$lang['cal_tu'] 		= "Ti";
$lang['cal_we'] 		= "Ke";
$lang['cal_th'] 		= "To";
$lang['cal_fr'] 		= "Pe";
$lang['cal_sa'] 		= "La";
$lang['cal_sun'] 		= "Sun";
$lang['cal_mon'] 		= "Maa";
$lang['cal_tue'] 		= "Tii";
$lang['cal_wed'] 		= "Kes";
$lang['cal_thu'] 		= "Tor";
$lang['cal_fri'] 		= "Per";
$lang['cal_sat'] 		= "Lau";
$lang['cal_sunday']		= "Sunnuntai";
$lang['cal_monday']		= "Maanantai";
$lang['cal_tuesday']	= "Tiistai";
$lang['cal_wednesday']	= "Keskiviikko";
$lang['cal_thursday']	= "Torstai";
$lang['cal_friday']		= "Perjantai";
$lang['cal_saturday']	= "Lauantai";
$lang['cal_jan'] 		= "Tam";
$lang['cal_feb'] 		= "Hel";
$lang['cal_mar'] 		= "Maa";
$lang['cal_apr'] 		= "Huh";
$lang['cal_may'] 		= "Tou";
$lang['cal_jun'] 		= "Kes";
$lang['cal_jul'] 		= "Hei";
$lang['cal_aug'] 		= "Elo";
$lang['cal_sep'] 		= "Syy";
$lang['cal_oct'] 		= "Lok";
$lang['cal_nov'] 		= "Mar";
$lang['cal_dec'] 		= "Jou";
$lang['cal_january'] 	= "Tammikuu";
$lang['cal_february'] 	= "Helmikuu";
$lang['cal_march'] 		= "Maaliskuu";
$lang['cal_april']		= "Huhtikuu";
$lang['cal_mayl'] 		= "Toukokuu";
$lang['cal_june'] 		= "Kesäkuu";
$lang['cal_july'] 		= "Heinäkuu";
$lang['cal_august']		= "Elokuu";
$lang['cal_september']	= "Syyskuu";
$lang['cal_october'] 	= "Lokakuu";
$lang['cal_november']	= "Marraskuu";
$lang['cal_december'] 	= "Joulukuu";


/* End of file calendar_lang.php */
/* Location: ./system/language/finnish/calendar_lang.php */