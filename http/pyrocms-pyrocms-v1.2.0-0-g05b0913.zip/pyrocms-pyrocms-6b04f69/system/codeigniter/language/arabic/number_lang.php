<?php

$lang['terabyte_abbr'] = "ت.ب";
$lang['gigabyte_abbr'] = "ج.ب";
$lang['megabyte_abbr'] = "م.ب";
$lang['kilobyte_abbr'] = "ك.ب";
$lang['bytes'] = "بايت";

/* End of file number_lang.php */
/* Location: ./system/language/arabic/number_lang.php */
