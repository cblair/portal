<ol>
	<li class="even">
		<label>Username</label>
		<?php echo form_input('username', $options['username']); ?>
	</li>
	<li class="even">
		<label>Number of items</label>
		<?php echo form_input('number', $options['number']); ?>
	</li>
</ol>