<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['intro']	=	'簡介';
$lang['step1']	=	'步驟一';
$lang['step2']	=	'步驟二';
$lang['step3']	=	'步驟三';
$lang['step4']	=	'步驟四';
$lang['final']	=	'最後一步';

$lang['installer.passwords_match']		= "Passwords Match."; #translate
$lang['installer.passwords_dont_match']	= "Passwords Don\'t Match."; #translate