<?php defined('BASEPATH') OR exit('No direct script access allowed');

// labels
$lang['congrats']	=	'Félicitations';
$lang['intro_text']	=	'PyroCMS est maintenant installé et à être utilisé ! Connectez-vous au panel d\'administration avec les détails suivants.';
$lang['email']		=	'E-mail';
$lang['password']	=	'Mot de passe';
$lang['outro_text']	=	'Pour finir, <strong>effacer le répertoire /installer de votre serveur</strong> afin d\'éviter qu\'il soit utilisé pour pirater votre site.';

$lang['go_website']			= 'Go to Website'; #translate
$lang['go_control_panel']	= 'Go to Control Panel'; #translate