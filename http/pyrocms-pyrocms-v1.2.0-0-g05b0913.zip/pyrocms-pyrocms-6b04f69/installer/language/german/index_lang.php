<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['header']	  = 'Willkomen';
$lang['thankyou'] = 'Danke das Sie sich f&uuml;rs PyroCMS! Entschieden haben.';
$lang['text']	  = 'Es ist sehr einfach das PyroCMS zu Installieren, Folge einfach den folgenden schritten und Mitteilungen.';
$lang['step1'] 	  = 'Schritt 1';
$lang['link']	  = 'Beginn mit dem ersten Schritt.';
