<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['intro']	=	'Introduzione';
$lang['step1']	=	'Passo #1';
$lang['step2']	=	'Passo #2';
$lang['step3']	=	'Passo #3';
$lang['step4']	=	'Passo #4';
$lang['final']	=	'Passo Finale';

$lang['installer.passwords_match']		= "Passwords Match."; #translate
$lang['installer.passwords_dont_match']	= "Passwords Don\'t Match."; #translate