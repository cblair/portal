<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['header']		= 'Seja bem vindo(a)';
$lang['thankyou']	= 'Obrigado por escolher PyroCMS!';
$lang['text']		= 'Instalar o PyroCMS é muito simples, apenas siga os passos e mensagens em sua tela. Caso você tenha algum tipo de problema instalando o sistema, não se preocupe, o instalador irá explicar tudo o que você precisa fazer.';
$lang['step1'] 		= 'Etapa 1';
$lang['link']		= 'Siga para a primeira etapa';
