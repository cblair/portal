<?php defined('BASEPATH') OR exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Parabéns';
$lang['intro_text']			= 'PyroCMS agora está instalado e pronto para uso! Para entrar no painel administrativo utilize as seguintes informações.';
$lang['email']				= 'E-mail';
$lang['password']			= 'Senha';
$lang['outro_text']			= 'Finalmente, <strong>remova o instalador de seu servidor</strong>, caso contrário, ele poderá ser utilizado para hackear o seu website.';

$lang['go_website']			= 'Ver o Website';
$lang['go_control_panel']	= 'Entrar no Painel de controle';