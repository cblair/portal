<?php defined('BASEPATH') OR exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Sveikiname';
$lang['intro_text']			= 'PyroCMS yra sėkmingai instaliuotas! Prašome prisijungti prie administravimo paneles naudojant žemiau nurodytus duomenys.';
$lang['email']				= 'El. paštas';
$lang['password']			= 'Slaptažodis';
$lang['outro_text']			= 'Galiausiai, <strong>ištrinkite katalogą installer iš jūsų serverio</strong> kadangi palikus jį rizikuojate, kad jūsų svetainė bus nulaužta';

$lang['go_website']			= 'Eiti į puslapį';
$lang['go_control_panel']	= 'Eiti į Turinio Valdymo Panelę';

/* End of file complete_lang.php */
/* Location: ./installer/language/english/complete_lang.php */