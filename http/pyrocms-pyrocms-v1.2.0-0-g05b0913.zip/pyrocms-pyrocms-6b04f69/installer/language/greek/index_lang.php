<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['header']		=	'Καλώσήρθατε';
$lang['thankyou']	= 	'Ευχαριστούμε που επιλέξατε το PyroCMS!';
$lang['text']		=	'Η εγκατάσταση του PyroCMS είναι πολύ εύκολη, απλώς ακολουθήστε τα βήματα και τα μηνύματα που εμφανίζονται στην οθόνη σας. Σε περίπτωση που έχετε κάποιο πρόβλημα κατά την εγκατάσταση του συστήματος, μην ανυσηχείτε, το πρόγραμμα εγκατάστασης θα σας εξηγεί τι πρέπει να κάνετε.';
$lang['step1'] 		= 'Βήμα 1';
$lang['link']		= 'Προχωρήστε στο πρώτο βήμα';

/* End of file index_lang.php */
/* Location: ./installer/language/greek/index_lang.php */
